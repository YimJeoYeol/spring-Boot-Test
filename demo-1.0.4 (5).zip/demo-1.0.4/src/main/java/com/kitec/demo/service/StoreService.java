package com.kitec.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
//import jakarta.transaction.Transactional;

import com.kitec.demo.domain.entity.Store;
import com.kitec.demo.domain.entity.User;
import com.kitec.demo.repository.StoreRepository;

import lombok.RequiredArgsConstructor;

@Transactional(readOnly = true)
@RequiredArgsConstructor
@Service
public class StoreService {

	private final StoreRepository storeRepository;
	
	public Store select(Long id) {
		Store store = storeRepository.findDistinctWithUserById(id).orElse(null);
		//Store store = storeRepository.findById(id).orElse(null);
		//Optional.ofNullable(store.getUser()).ifPresent(user -> user.getName());
		return store;
	}
	
	public List<Store> select() {
		//List<Store> stores = storeRepository.findAll();  //--> join이 안됨
		//stores.stream().forEach(store -> Optional.ofNullable(store.getUser()).map(User::getName));
		//findDistinctWithUserBy
		List<Store> stores = storeRepository.findDistinctWithUserBy();
		
		return stores;
	}

	/*
	public Store select(Long id) {
		Store store = storeRepository.findById(id).orElse(null);
		// Transactional 내부에서 연관관계 미리 조회
		Optional.ofNullable(store.getUser()).ifPresent(user -> user.getName());
		return store;
	}
	*/

}
