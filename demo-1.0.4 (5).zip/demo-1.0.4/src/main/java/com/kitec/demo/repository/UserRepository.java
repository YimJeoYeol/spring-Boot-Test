package com.kitec.demo.repository;


import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;

import com.kitec.demo.domain.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {

	//Optional<User> findById(Long id);
	//User save(User user);                                                      
	Optional<User> findByEmail(String email);
	//void delete(User user);
		 
	 
	@Query("SELECT DISTINCT u FROM User u join fetch u.stores WHERE u.id = ?1")
	//@EntityGraph(attributePaths = "stores")
	Optional<User> findDistinctWithStoresById(Long id);
	
	@Query("SELECT DISTINCT u FROM User u join fetch u.stores")
	//@EntityGraph(attributePaths = "stores")
	List<User> findDistinctWithStoresBy();
	
	
	
	
}
