package com.kitec.demo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.kitec.demo.domain.entity.Store;

public interface StoreRepository extends JpaRepository<Store, Long> {
	
	//@Query("SELECT DISTINCT s FROM Store s join fetch s.user WHERE s.id = ?1")
	//@EntityGraph(attributePaths = "user", type = EntityGraph.EntityGraphType.LOAD)	
    //Optional<Store> findDistinctWithUserById(Long id);
	
    
	//@EntityGraph(attributePaths = "user")
	@Query("SELECT DISTINCT s FROM Store s join fetch s.user")
    List<Store> findDistinctWithUserBy();
	
	
	//@EntityGraph(attributePaths = "user", type = EntityGraph.EntityGraphType.LOAD)
	@Query("SELECT DISTINCT s FROM Store s join fetch s.user WHERE s.id = ?1")
    Optional<Store> findDistinctWithUserById(Long id);

}
